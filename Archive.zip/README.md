# Trainfuel

Simple app that I am building to help leverage AI and Strava data for training
